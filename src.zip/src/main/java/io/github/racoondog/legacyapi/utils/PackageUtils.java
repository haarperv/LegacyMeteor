package io.github.racoondog.legacyapi.utils;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class PackageUtils {
    public static String getLastDirectory(String packageName) {
        String[] tokens = packageName.split("\\.");
        return tokens[tokens.length - 1];
    }
}
